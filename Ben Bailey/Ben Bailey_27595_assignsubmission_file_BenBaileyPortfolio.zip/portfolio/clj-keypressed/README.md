# keypressed

A Quil sketch designed to change the color of the screen based on what keys you press.

## Compile

Run `lein uberjar` in the main directory to create a runnable java file.

Run `java -jar targetfile` to run the file, where targetfile is the path to the java file created in the previous step.

## License

Credit for initial Processing code to Gabrielle Morell

Distributed under the GNU GENERAL PUBLIC LICENSE Version 2
