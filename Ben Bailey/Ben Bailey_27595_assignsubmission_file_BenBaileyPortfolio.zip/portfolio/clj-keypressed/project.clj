(defproject keypressed "1.0"
  :description "Processing example that changes the screen's color based on what keys you press."
  :url ""
  :license {:name "GNU GPL v2.0"
            :url "https://www.gnu.org/licenses/gpl-2.0.txt"}
  :dependencies [[org.clojure/clojure "1.6.0"]
                 [quil "2.2.4"]]
  :main ^:skip-aot keypressed.core
  :profiles {:uberjar {:aot :all}})
