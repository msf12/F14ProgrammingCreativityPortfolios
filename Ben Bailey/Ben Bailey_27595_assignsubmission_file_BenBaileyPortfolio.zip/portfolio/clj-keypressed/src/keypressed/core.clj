; keypressed
; Original Processing code by Gabrielle Morell
; Converted to Clojure by Ben Bailey

(ns keypressed.core
  (:require [quil.core :as q]
            [quil.middleware :as m])
  (:gen-class))

(defn is-letter [c]
  (or (and (>= (int c) (int \A)) (<= (int c) (int \Z))) (and (>= (int c) (int \a)) (<= (int c) (int \z)))))

(defn letter-equal [c]
  (= (q/raw-key) c))

(defn setup []
  ; Set frame rate to 30 frames per second.
  (q/frame-rate 30)
  (q/background 0))

(defn update [state]
  ; Update sketch state by changing circle color and position.
  )

(defn draw [state]
  (if (q/key-pressed?)
    (cond
     (letter-equal \a) (q/background 0 0 255)
     (letter-equal \b) (q/background 22 106 217)
     (letter-equal \c) (q/background 22 197 217)
     (letter-equal \d) (q/background 22 217 171)
     (letter-equal \e) (q/background 22 217 96)
     (letter-equal \f) (q/background 22 217 22)
     (letter-equal \g) (q/background 142 217 22)
     (letter-equal \h) (q/background 217 217 22)
     (letter-equal \i) (q/background 217 187 22)
     (letter-equal \j) (q/background 217 148 22)
     (letter-equal \k) (q/background 217 119 22)
     (letter-equal \l) (q/background 217 77 22)
     (letter-equal \m) (q/background 217 22 22)
     (letter-equal \n) (q/background 217 22 80)
     (letter-equal \o) (q/background 217 22 142)
     (letter-equal \p) (q/background 197 22 217)
     (letter-equal \q) (q/background 145 22 217)
     (letter-equal \r) (q/background 116 22 171)
     (letter-equal \s) (q/background 74 22 217)
     (letter-equal \t) (q/background 22 38 217)
     (letter-equal \u) (q/background 22 83 217)
     (letter-equal \v) (q/background 22 126 217)
     (letter-equal \w) (q/background 22 171 217)
     (letter-equal \x) (q/background 22 207 217)
     (letter-equal \y) (q/background 22 217 184)
     (letter-equal \z) (q/background 22 217 161)
     :else (q/background 0)
     )))

(defn -main [& args]
  (q/defsketch keypressed
  :title "keypressed"
  :size [640 360]
  :setup setup
  :update update
  :draw draw
  :middleware [m/fun-mode]
  :features [:exit-on-close]))
