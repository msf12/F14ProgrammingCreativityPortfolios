(ns randshapes.core
  (:require [quil.core :as q]
            [quil.middleware :as m])
  (:gen-class))

(defn circle [x y diameter r g b t]
  (q/fill r g b t)
  (q/ellipse x y diameter diameter))

(defn rand-255 []
  (q/random 255))

(defn setup []
  ; Set frame rate to 30 frames per second.
  (q/background 255 255 255 20)
  (q/frame-rate 30)
  (q/no-stroke)
  {:z 0})

(defn update [state]
  ; Update sketch state by changing circle color and position.
  {:z (mod (+ 5 (:z state)) 255)})

(defn draw [state]
  (q/background (:z state) (:z state) (:z state))
  (doseq [i (range 0 480)] (do (circle i i 80 (rand-255) (rand-255) (rand-255) (rand-255)) (circle (- (q/width) i) i 80 (rand-255) (rand-255) (rand-255) (rand-255)))))

(defn -main [& args]
  (q/defsketch randshapes
    :title "X Marks The Spot"
    :size [480 480]
    :setup setup
    :update update
    :draw draw
    :middleware [m/fun-mode]
    :features [:exit-on-close]))
