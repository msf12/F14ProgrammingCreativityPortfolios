import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class foxy extends PApplet {

//Valentina Forte-Hernandez
//11920014
public void setup()
{
  strokeWeight(0);
  size(800, 450);
  smooth();
}

public void draw()
{
fill(219, 142, 85); // light orange
triangle (400, 400, 400, 150, 300, 200); //left base
triangle (400, 190, 400, 50, 300, 130); //left cheek
triangle (400, 190, 400, 50, 500, 130); //right cheek

fill(188, 85, 0); //dark orange
triangle (400, 400, 400, 150, 500, 200); //right base

triangle (300, 200, 320, 380, 400, 400); //tail base

beginShape (); //left ear outline
vertex (300, 130);
vertex (290, 120);
vertex (325, 90);
vertex (340, 25);
vertex (385, 60);
endShape();

beginShape (); //right ear outline
vertex (500, 130);
vertex (510, 120);
vertex (475, 90);
vertex (460, 25);
vertex (415, 60);
endShape();

fill(255);// white
beginShape (); //face marking
vertex(400, 190);
vertex(353, 160);
vertex(395, 150);
vertex (385, 120);
vertex(400, 50);
vertex(415, 120);
vertex(405, 150);
vertex(447, 160);
vertex(400, 190);
endShape();


fill(0);//black parts
triangle(420, 65, 455, 33, 457, 95); //right inner ear
triangle (380, 65, 345, 33, 343, 95); // left inner ear

triangle (310, 300, 320, 150, 250, 150); //tail tip

triangle (400, 400, 400, 380, 410, 380); //right paw
triangle (400, 400, 400, 380, 390, 380); //left paw

triangle(400, 187, 380, 165, 420, 165); //snout

ellipse(370, 130, 10, 10); //left eye
ellipse(430, 130, 10, 10); //right eye

line(390, 170, 370, 175);
line(390, 170, 370, 165);
line(410, 170, 430, 175);
line(410, 170, 430, 165);

}



  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "foxy" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
